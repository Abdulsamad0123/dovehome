export interface Property {
  id: string;
  title: string;
  location: string;
  price: string;
  priceNumeric: number;
  bedrooms: number;
  bathrooms: number;
  area: string;
  type: string;
  status: "For Sale" | "For Rent";
  image: string;
  description: string;
  features: string[];
}

export const properties: Property[] = [
  {
    id: "1",
    title: "Luxury Villa in Maitama",
    location: "Maitama, Abuja",
    price: "₦450,000,000",
    priceNumeric: 450000000,
    bedrooms: 6,
    bathrooms: 7,
    area: "850 sqm",
    type: "Villa",
    status: "For Sale",
    image: "https://images.unsplash.com/photo-1585011191285-8b443579631c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBsdXh1cnklMjB2aWxsYSUyMG5pZ2VyaWF8ZW58MXx8fHwxNzcxOTI2Mzk2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    description: "Exquisite luxury villa featuring modern architecture, premium finishes, and breathtaking city views in the prestigious Maitama district.",
    features: ["Swimming Pool", "Smart Home", "Garden", "Security", "Gym", "Cinema Room"]
  },
  {
    id: "2",
    title: "Premium Apartment in Asokoro",
    location: "Asokoro, Abuja",
    price: "₦185,000,000",
    priceNumeric: 185000000,
    bedrooms: 4,
    bathrooms: 5,
    area: "320 sqm",
    type: "Apartment",
    status: "For Sale",
    image: "https://images.unsplash.com/photo-1619647787040-5583f41eb9b5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBhcGFydG1lbnQlMjBidWlsZGluZ3xlbnwxfHx8fDE3NzE4OTQ0MjJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    description: "Contemporary luxury apartment in an exclusive high-rise building, offering panoramic views and world-class amenities.",
    features: ["24/7 Security", "Concierge", "Parking", "Generator", "Elevator", "Balcony"]
  },
  {
    id: "3",
    title: "Modern Estate House in Guzape",
    location: "Guzape District, Abuja",
    price: "₦320,000,000",
    priceNumeric: 320000000,
    bedrooms: 5,
    bathrooms: 6,
    area: "650 sqm",
    type: "Detached House",
    status: "For Sale",
    image: "https://images.unsplash.com/photo-1549357957-99ab8644c268?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBlc3RhdGUlMjBob3VzZXxlbnwxfHx8fDE3NzE5MjYzOTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    description: "Stunning modern estate house with sleek design, expansive living spaces, and premium fixtures in Guzape District.",
    features: ["Private Parking", "Garden", "Security", "BQ", "Solar Power", "Modern Kitchen"]
  },
  {
    id: "4",
    title: "Penthouse Suite in Wuse 2",
    location: "Wuse 2, Abuja",
    price: "₦275,000,000",
    priceNumeric: 275000000,
    bedrooms: 4,
    bathrooms: 5,
    area: "420 sqm",
    type: "Penthouse",
    status: "For Sale",
    image: "https://images.unsplash.com/photo-1677553512940-f79af72efd1b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBwZW50aG91c2UlMjBpbnRlcmlvcnxlbnwxfHx8fDE3NzE4MjkzODV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    description: "Exclusive penthouse with luxurious interiors, floor-to-ceiling windows, and spectacular views of Abuja's skyline.",
    features: ["Roof Terrace", "Smart Home", "Gym", "Wine Cellar", "Premium Finishes", "Concierge"]
  },
  {
    id: "5",
    title: "Contemporary Mansion in Katampe",
    location: "Katampe, Abuja",
    price: "₦580,000,000",
    priceNumeric: 580000000,
    bedrooms: 7,
    bathrooms: 8,
    area: "1200 sqm",
    type: "Mansion",
    status: "For Sale",
    image: "https://images.unsplash.com/photo-1767467978344-5291d812d125?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb250ZW1wb3JhcnklMjBtYW5zaW9uJTIwZXh0ZXJpb3J8ZW58MXx8fHwxNzcxOTI2Mzk3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    description: "Magnificent contemporary mansion set on expansive grounds, featuring state-of-the-art amenities and architectural excellence.",
    features: ["Tennis Court", "Pool", "Cinema", "Gym", "Staff Quarters", "Smart Security"]
  },
  {
    id: "6",
    title: "Luxury Duplex in Jabi",
    location: "Jabi, Abuja",
    price: "₦155,000,000",
    priceNumeric: 155000000,
    bedrooms: 5,
    bathrooms: 5,
    area: "480 sqm",
    type: "Duplex",
    status: "For Sale",
    image: "https://images.unsplash.com/photo-1757924284732-4189190321cf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBkdXBsZXglMjBob3VzZXxlbnwxfHx8fDE3NzE5MjYzOTd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    description: "Elegant duplex residence with contemporary design, premium materials, and excellent location near shopping and dining.",
    features: ["Parking", "Garden", "BQ", "Security", "Modern Kitchen", "Spacious Rooms"]
  },
  {
    id: "7",
    title: "Modern Townhouse in Galadimawa",
    location: "Galadimawa, Abuja",
    price: "₦95,000,000",
    priceNumeric: 95000000,
    bedrooms: 4,
    bathrooms: 4,
    area: "280 sqm",
    type: "Townhouse",
    status: "For Sale",
    image: "https://images.unsplash.com/photo-1630404515111-2fc17457daa6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjB0b3duaG91c2UlMjBhcmNoaXRlY3R1cmV8ZW58MXx8fHwxNzcxOTExODIxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    description: "Stylish modern townhouse in a gated community, perfect for families seeking comfort and security.",
    features: ["Gated Estate", "Parking", "Garden", "24/7 Security", "Power Supply", "Playground"]
  },
  {
    id: "8",
    title: "Luxury Bungalow in Lugbe",
    location: "Lugbe, Abuja",
    price: "₦72,000,000",
    priceNumeric: 72000000,
    bedrooms: 3,
    bathrooms: 3,
    area: "350 sqm",
    type: "Bungalow",
    status: "For Sale",
    image: "https://images.unsplash.com/photo-1740479948645-3eb39a64e843?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBidW5nYWxvdyUyMGhvbWV8ZW58MXx8fHwxNzcxOTI2Mzk3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    description: "Charming luxury bungalow with spacious rooms, beautiful garden, and serene environment ideal for retirement or small families.",
    features: ["Garden", "Parking", "BQ", "Security", "Generator", "Quiet Location"]
  },
  {
    id: "9",
    title: "Premium Residential Estate in Life Camp",
    location: "Life Camp, Abuja",
    price: "₦125,000,000",
    priceNumeric: 125000000,
    bedrooms: 4,
    bathrooms: 4,
    area: "380 sqm",
    type: "Detached House",
    status: "For Sale",
    image: "https://images.unsplash.com/photo-1758193431355-54df41421657?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwcmVzaWRlbnRpYWwlMjBlc3RhdGV8ZW58MXx8fHwxNzcxOTI2Mzk4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    description: "Beautiful detached house in premium residential estate, offering modern living with excellent community amenities.",
    features: ["Estate Facilities", "Swimming Pool Access", "Gym", "Security", "Parking", "Garden"]
  },
  {
    id: "10",
    title: "Luxury Condominium in Central Business District",
    location: "Central Area, Abuja",
    price: "₦210,000,000",
    priceNumeric: 210000000,
    bedrooms: 3,
    bathrooms: 4,
    area: "290 sqm",
    type: "Condominium",
    status: "For Rent",
    image: "https://images.unsplash.com/photo-1766270596305-d0cfb9efaa52?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBjb25kb21pbml1bSUyMGJ1aWxkaW5nfGVufDF8fHx8MTc3MTgzNjUwMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    description: "Ultra-modern condominium in the heart of Abuja's CBD, perfect for professionals and executives seeking convenience and luxury.",
    features: ["24/7 Power", "Concierge", "Parking", "Security", "Gym", "Business Center"]
  }
];

import { DoveHeader } from "../components/DoveHeader";
import { DoveFooter } from "../components/DoveFooter";
import { motion } from "motion/react";
import { useState } from "react";
import { MapPin, Phone, Mail, Clock } from "lucide-react";

export function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert("Thank you for contacting Dove Homes! We'll get back to you shortly.");
    setFormData({ name: "", email: "", phone: "", message: "" });
  };

  return (
    <div className="min-h-screen bg-white">
      <DoveHeader />
      
      {/* Hero Section */}
      <section className="relative h-[50vh] flex items-center justify-center bg-gradient-to-br from-[#2d2d2d] to-[#4d4d4d] overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-64 h-64 bg-[#c9a961] rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-[#c9a961] rounded-full blur-3xl" />
        </div>
        
        <div className="relative z-10 text-center px-6">
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-5xl lg:text-6xl text-white mb-6"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Get In Touch
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-xl text-white/80 max-w-2xl mx-auto"
            style={{ fontFamily: "'Inter', sans-serif", fontWeight: 300 }}
          >
            We'd love to hear from you. Reach out to our team today.
          </motion.p>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-24 lg:py-32">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            {/* Contact Info */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-4xl text-[#2d2d2d] mb-8" style={{ fontFamily: "'Playfair Display', serif" }}>
                Visit Our Office
              </h2>
              
              <div className="space-y-6 mb-12">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#c9a961]/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-[#c9a961]" />
                  </div>
                  <div>
                    <h3 className="text-lg text-[#2d2d2d] mb-1" style={{ fontFamily: "'Inter', sans-serif", fontWeight: 600 }}>
                      Address
                    </h3>
                    <p className="text-[#5a5a5a]" style={{ fontFamily: "'Inter', sans-serif", fontWeight: 300 }}>
                      Plot 123, Maitama District<br />
                      Abuja, FCT, Nigeria
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#c9a961]/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <Phone className="w-6 h-6 text-[#c9a961]" />
                  </div>
                  <div>
                    <h3 className="text-lg text-[#2d2d2d] mb-1" style={{ fontFamily: "'Inter', sans-serif", fontWeight: 600 }}>
                      Phone
                    </h3>
                    <p className="text-[#5a5a5a]" style={{ fontFamily: "'Inter', sans-serif", fontWeight: 300 }}>
                      +234 (0) 800 123 4567<br />
                      +234 (0) 800 765 4321
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#c9a961]/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <Mail className="w-6 h-6 text-[#c9a961]" />
                  </div>
                  <div>
                    <h3 className="text-lg text-[#2d2d2d] mb-1" style={{ fontFamily: "'Inter', sans-serif", fontWeight: 600 }}>
                      Email
                    </h3>
                    <p className="text-[#5a5a5a]" style={{ fontFamily: "'Inter', sans-serif", fontWeight: 300 }}>
                      info@dovehomes.ng<br />
                      sales@dovehomes.ng
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#c9a961]/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <Clock className="w-6 h-6 text-[#c9a961]" />
                  </div>
                  <div>
                    <h3 className="text-lg text-[#2d2d2d] mb-1" style={{ fontFamily: "'Inter', sans-serif", fontWeight: 600 }}>
                      Office Hours
                    </h3>
                    <p className="text-[#5a5a5a]" style={{ fontFamily: "'Inter', sans-serif", fontWeight: 300 }}>
                      Monday - Friday: 9:00 AM - 6:00 PM<br />
                      Saturday: 10:00 AM - 4:00 PM<br />
                      Sunday: Closed
                    </p>
                  </div>
                </div>
              </div>

              {/* Map Placeholder */}
              <div className="bg-gray-200 rounded-2xl h-64 flex items-center justify-center">
                <p className="text-gray-500" style={{ fontFamily: "'Inter', sans-serif" }}>
                  Map Location
                </p>
              </div>
            </motion.div>

            {/* Contact Form */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <div className="bg-[#fafaf8] p-8 lg:p-12 rounded-2xl shadow-lg">
                <h2 className="text-3xl text-[#2d2d2d] mb-6" style={{ fontFamily: "'Playfair Display', serif" }}>
                  Send Us a Message
                </h2>
                
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label className="block text-sm text-[#5a5a5a] mb-2" style={{ fontFamily: "'Inter', sans-serif", fontWeight: 500 }}>
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:border-[#c9a961] transition-colors"
                      style={{ fontFamily: "'Inter', sans-serif" }}
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-[#5a5a5a] mb-2" style={{ fontFamily: "'Inter', sans-serif", fontWeight: 500 }}>
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:border-[#c9a961] transition-colors"
                      style={{ fontFamily: "'Inter', sans-serif" }}
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-[#5a5a5a] mb-2" style={{ fontFamily: "'Inter', sans-serif", fontWeight: 500 }}>
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:border-[#c9a961] transition-colors"
                      style={{ fontFamily: "'Inter', sans-serif" }}
                    />
                  </div>

                  <div>
                    <label className="block text-sm text-[#5a5a5a] mb-2" style={{ fontFamily: "'Inter', sans-serif", fontWeight: 500 }}>
                      Message *
                    </label>
                    <textarea
                      required
                      rows={6}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:border-[#c9a961] transition-colors resize-none"
                      style={{ fontFamily: "'Inter', sans-serif" }}
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full px-8 py-4 bg-[#c9a961] text-white rounded-full hover:bg-[#b8984f] transition-all duration-300 text-sm tracking-wide"
                    style={{ fontFamily: "'Inter', sans-serif", fontWeight: 500 }}
                  >
                    Send Message
                  </button>
                </form>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <DoveFooter />
    </div>
  );
}

import { DoveHeader } from "../components/DoveHeader";
import { DoveFooter } from "../components/DoveFooter";
import { motion } from "motion/react";
import { useRef } from "react";
import { useInView } from "../hooks/useInView";
import { Mail, Linkedin } from "lucide-react";

interface TeamMember {
  name: string;
  title: string;
  image: string;
  bio: string;
  email: string;
}

const teamMembers: TeamMember[] = [
  {
    name: "Engr. Emmanuel Omede",
    title: "Chief Executive Officer",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZnJpY2FuJTIwYnVzaW5lc3MlMjBtYW58ZW58MXx8fHwxNzcxOTI2Mzk4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    bio: "Engr. Emmanuel Omede is a visionary leader with over 15 years of experience in luxury real estate development and engineering. His commitment to excellence and innovation has positioned Dove Homes as a premier real estate company in Abuja.",
    email: "emmanuel.omede@dovehomes.ng"
  },
  {
    name: "Miss Lilian",
    title: "General Manager",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZnJpY2FuJTIwYnVzaW5lc3MlMjB3b21hbnxlbnwxfHx8fDE3NzE5MjYzOTh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    bio: "Miss Lilian brings exceptional leadership and operational excellence to Dove Homes. With her strategic mindset and dedication to client satisfaction, she ensures every project meets the highest standards of quality and luxury.",
    email: "lilian@dovehomes.ng"
  },
  {
    name: "Miss Chioma",
    title: "Office Assistant",
    image: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZnJpY2FuJTIwcHJvZmVzc2lvbmFsJTIwd29tYW58ZW58MXx8fHwxNzcxOTI2Mzk4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    bio: "Miss Chioma is the welcoming face of Dove Homes, providing exceptional administrative support and ensuring seamless client experiences. Her attention to detail and warm personality make every interaction memorable.",
    email: "chioma@dovehomes.ng"
  }
];

export function LeadershipPage() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  return (
    <div className="min-h-screen bg-white">
      <DoveHeader />
      
      {/* Hero Section */}
      <section className="relative h-[50vh] flex items-center justify-center bg-gradient-to-br from-[#2d2d2d] to-[#4d4d4d] overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-64 h-64 bg-[#c9a961] rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-[#c9a961] rounded-full blur-3xl" />
        </div>
        
        <div className="relative z-10 text-center px-6">
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-5xl lg:text-6xl text-white mb-6"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Our Leadership Team
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-xl text-white/80 max-w-2xl mx-auto"
            style={{ fontFamily: "'Inter', sans-serif", fontWeight: 300 }}
          >
            Meet the passionate individuals driving Dove Homes forward
          </motion.p>
        </div>
      </section>

      {/* Team Grid */}
      <section className="py-24 lg:py-32" ref={ref}>
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
            {teamMembers.map((member, index) => (
              <motion.div
                key={member.name}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                className="group"
              >
                <div className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300">
                  {/* Image */}
                  <div className="relative h-80 overflow-hidden">
                    <img
                      src={member.image}
                      alt={member.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    
                    {/* Social Links */}
                    <div className="absolute bottom-4 left-4 flex gap-3">
                      <a
                        href={`mailto:${member.email}`}
                        className="w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-[#c9a961] hover:text-white transition-colors"
                      >
                        <Mail className="w-5 h-5" />
                      </a>
                      <a
                        href="#"
                        className="w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-[#c9a961] hover:text-white transition-colors"
                      >
                        <Linkedin className="w-5 h-5" />
                      </a>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-6">
                    <h3
                      className="text-2xl text-[#2d2d2d] mb-1"
                      style={{ fontFamily: "'Playfair Display', serif" }}
                    >
                      {member.name}
                    </h3>
                    <p
                      className="text-[#c9a961] mb-4 text-sm tracking-wide"
                      style={{ fontFamily: "'Inter', sans-serif", fontWeight: 500 }}
                    >
                      {member.title}
                    </p>
                    <p
                      className="text-[#5a5a5a] leading-relaxed"
                      style={{ fontFamily: "'Inter', sans-serif", fontWeight: 300 }}
                    >
                      {member.bio}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-24 bg-[#fafaf8]">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2
              className="text-4xl lg:text-5xl text-[#2d2d2d] mb-6"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              Our Core Values
            </h2>
            <p
              className="text-lg text-[#5a5a5a] max-w-2xl mx-auto"
              style={{ fontFamily: "'Inter', sans-serif", fontWeight: 300 }}
            >
              The principles that guide everything we do at Dove Homes
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: "Excellence",
                description: "We pursue perfection in every property and every interaction, never settling for anything less than extraordinary."
              },
              {
                title: "Integrity",
                description: "Transparency and honesty form the foundation of our relationships with clients, partners, and our community."
              },
              {
                title: "Innovation",
                description: "We embrace modern approaches and cutting-edge solutions to deliver properties that exceed expectations."
              }
            ].map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.8, delay: 0.2 + index * 0.1 }}
                className="bg-white p-8 rounded-2xl shadow-lg"
              >
                <h3
                  className="text-2xl text-[#2d2d2d] mb-4"
                  style={{ fontFamily: "'Playfair Display', serif" }}
                >
                  {value.title}
                </h3>
                <p
                  className="text-[#5a5a5a] leading-relaxed"
                  style={{ fontFamily: "'Inter', sans-serif", fontWeight: 300 }}
                >
                  {value.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <DoveFooter />
    </div>
  );
}
